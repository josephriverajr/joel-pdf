<?php
session_start();
//get ulit ung id sa url
$user_id = $_GET['user_id'];
$conn=mysqli_connect("localhost", "root", "", "mysql");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
// db query
  $result = mysqli_query($conn, "SELECT * FROM asample Where ID=".$user_id);
// ito nirerequire bali dto nya lahat kinukuha ung components ng pdf
require('fpdf181/fpdf.php');
//initialize ng pade
$pdf = new FPDF('P','mm','A4');
$pdf->AddPage();
// settings ng fonts
$pdf->SetFont('Arial','',12);
//while or pag display same sa tale
while($row = mysqli_fetch_array($result)) {
$pdf->Cell(10,10,'Fname : '.$row['Firstname'],'B',0);
$pdf->ln();
$pdf->Cell(15,10,'Lname : '.$row['Lastname'],'B',0);
} 
//pag download ng pdf
$pdf->Output('D','filename.pdf');









?>
