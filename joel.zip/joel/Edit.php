<!DOCTYPE html>
<HTML>
<HEAD>
<TITLE>
Edit
</TITLE>
</HEAD>
<BODY>

<a href="1.php">Back</a>
<br><br>
<form method="POST">
<?php
$conn=mysqli_connect("localhost", "root", "", "asample");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}
	$user_id = $_GET['user_id'];

	$result = mysqli_query($conn, "SELECT * FROM asample Where ID=".$user_id);
  while($row = mysqli_fetch_array($result)) {
  echo "FirstName : <input type=text name=Firstname value=".$row['Firstname']."><br><br>";
  echo "Lastname : <input type=text name=Lastname value=".$row['Lastname']."><br><br>";
}
echo "<input type=submit name=edit value=Edit>";
if(isset($_POST['edit']))
{
    $Firstname = $_POST['Firstname'];
    
    $edit = mysqli_query($conn,"UPDATE asample SET Firstname='$Firstname' Where ID=".$user_id);
    if(!$edit)
    {
        echo mysqli_error();
    }
    else
    {
        echo "Records are updated successfully.";
    }
}

echo "$user_id";
mysqli_close($conn);
?>
</form>

</BODY>
</HTML>