<!DOCTYPE html>
<HTML>
<HEAD>
<TITLE>
HEHI
</TITLE>
</HEAD>
<BODY>

<form method="POST">
  FirstName : <input type="text" name="Firstname" placeholder="Firstname"><br>
  <br>
  Lastname : <input type="text" name="Lastname" placeholder="Lastname"><br>
  <br>
  <input type="submit" name="submit" value="Add">
  <input type="submit" name="delete" value="Delete">

<table style="width:25%">
  <tr>
    <th>Firstname</th>
    <th>Lastname</th>
  </tr>
</table>

<?php
$conn=mysqli_connect("localhost", "root", "", "asample");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

$result = mysqli_query($conn, "SELECT * FROM asample");

while($row = mysqli_fetch_array($result)) {
    echo "<table>";
    echo "<tr>";
    echo "<td><input type=checkbox name=checkbox[] value=".$row["id"]."></td>";
    echo "<td width=190px>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp" . $row["Firstname"]."</td>";
    echo "<td width=100px>" . $row["Lastname"]. "</td>";
    echo "<td><input type=submit name=edit value=Edit></td>";
    echo "<td><a href=Edit.php?user_id=".$row['id']."> Edit </a></td>";
    echo "<td><a href=pdf.php?user_id=".$row['id']."> view </a></td>";
    echo "</tr>";
    echo "</table>";
  }

mysqli_close($conn);
?>
</form>




<?php
$conn=mysqli_connect("localhost", "root", "", "asample");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['delete']))
{		
    $check = $_POST['checkbox'];
    foreach($check as $id){
    $delete = mysqli_query($conn,"DELETE FROM asample Where ID=".$id);
    }

    if(!$delete)
    {
        echo mysqli_error();
    }
    else
    {
        echo "Records deleted successfully.";
    }
}
mysqli_close($conn);
?>

<?php
$conn=mysqli_connect("localhost", "root", "", "asample");
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST['submit']))
{		
    $Firstname = $_POST['Firstname'];
    $Lastname = $_POST['Lastname'];

    $insert = mysqli_query($conn,"INSERT INTO asample (Firstname, Lastname) VALUES ('$Firstname','$Lastname')");

    if(!$insert)
    {
        echo mysqli_error();
    }
    else
    {
        echo "Records added successfully.";
    }
}

mysqli_close($conn);
?>


</BODY>
</HTML>